🎮 How the Game Works (Quick Guide)

    Goal: Guess secret numbers between 0 and 9. Each correct guess gives you +1 point.

    First round:

        If you guess right → score 1 point and the number is removed.

        If you guess wrong → score stays at 0, and you can choose to restart.

    Next rounds:

        Each correct guess removes that number from the pool.

        If you miss → the game ends with your current score.

    Final round (only 2 numbers left):

        One last decisive guess.

        Correct → you win with 9 points.

        Wrong → the game ends with 8 points.

📝 Summary

    Every correct guess = +1 point.

    A mistake ends the game (unless it’s the very first try, where you can restart).

    With 2 numbers left, one final guess decides between 9 or 8 points.